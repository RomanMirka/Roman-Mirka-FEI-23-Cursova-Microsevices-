function updateFavoritesDisplay() {
    const favoritesContainer = document.querySelector('.product-grid');
    const emptyMessage = document.querySelector('.empty-fav');
    
    if (favoritesContainer.children.length === 0) {
        emptyMessage.style.display = 'block';
    } else {
        emptyMessage.style.display = 'none';
    }
}

function clearAllFavorites() {
    fetch('http://127.0.0.1:3004/api/favourites', {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            user_id: 1
        })
    })
    .then(response => {
        console.log("Response status:", response.status);
        if (response.ok) {
            document.querySelector('.product-grid').innerHTML = ''; 
            updateFavoritesDisplay();  
        } else {
            response.json().then(data => {
                console.error('Failed to remove all products from favorites:', data.message);
            });
        }
    })
    .catch(error => console.error('Error:', error));
}

fetch('http://127.0.0.1:3004/api/favourites')
    .then(response => response.json())
    .then(data => {
        const favoritesContainer = document.querySelector('.product-grid');
        if (data.length === 0) {
            favoritesContainer.innerHTML = '';
            updateFavoritesDisplay();  
        } else {
            data.forEach(favorite => {
    const productElement = document.createElement('div');
    productElement.classList.add('item');

    const productPageLink = `/product-service/product_page/${favorite.name.toLowerCase().replace(/\s+/g, '')}.html`;
    const isLiked = favorite.is_liked;

    productElement.innerHTML = `
        <a href="${productPageLink}">
           <img src="/../${favorite.image.replace(/\\/g, '/')}" alt="item" class="img" />
        </a>
        <div class="glass-item">
            <h2>${favorite.name}</h2>
            <p class="price">$${favorite.price}</p>
        </div>
        <img src="${isLiked ? 'img/heart2.png' : 'img/heart.png'}" 
             alt="like" id="heart-icon-${favorite.product_id}" 
             class="heart" 
             onclick="toggleLike(${favorite.product_id}, 'heart-icon-${favorite.product_id}')" />
    `;            
               favoritesContainer.appendChild(productElement);
            });
            updateFavoritesDisplay();  
        }
    })
    .catch(error => console.error('Error:', error));

function toggleLike(productId, likeId) {
    const heartIcon = document.getElementById(likeId);

    if (heartIcon.src.includes('heart2.png')) {
        fetch(`http://127.0.0.1:3004/api/favourites/${productId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            if (response.ok) {
                heartIcon.src = 'img/heart.png';
                console.log('Product removed from favorites');
                updateFavoritesDisplay();
            } else {
                response.json().then(data => console.error('Failed to remove product from favorites:', data.message));
            }
        })
        .catch(error => console.error('Error:', error));
    } else {
        fetch('http://127.0.0.1:3004/api/favourites', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: 1,  
                product_id: productId
            })
        })
        .then(response => {
            if (response.ok) {
                response.json().then(data => {
                    heartIcon.src = 'img/heart2.png';
                    console.log('Product added to favorites');
                    updateFavoritesDisplay();
                });
            } else {
                response.json().then(data => console.error('Failed to add product to favorites:', data.message));
            }
        })
        .catch(error => console.error('Error:', error));
    }
}

document.addEventListener('DOMContentLoaded', () => {
    updateFavoritesDisplay();
});
