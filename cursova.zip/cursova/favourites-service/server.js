const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());
app.use(express.static('img'));  

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', 
  password: '3011', 
  database: 'favourite_service'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to the database');
});

app.get('/', (req, res) => {
    res.send('Лайк сервіс працює!'); 
});

app.post('/api/favourites', (req, res) => {
  const { user_id, product_id } = req.body;
  const query = 'INSERT INTO favourites (user_id, product_id) VALUES (?, ?)';
  db.query(query, [user_id, product_id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(200).json({ message: 'Product added to favourites' });
  });
});

app.delete('/api/favourites', (req, res) => {
  const userId = 1; 
  const productId = req.params.productId;

  const query = 'DELETE FROM favourites WHERE user_id = 1';
  db.query(query, [userId, productId], (err, result) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to remove product from favorites', error: err });
    }

    res.status(200).json({ message: 'Product removed from favorites' });
  });
});

app.get('/api/favourites', (req, res) => {
  const query = `
    SELECT favourites.id, favourites.user_id, products.id AS product_id, products.name, products.image, products.price
    FROM favourite_service.favourites
    JOIN product_service.products ON favourite_service.favourites.product_id = product_service.products.id
  `;
  db.query(query, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(200).json(results);
  });
});

app.delete('/api/favourites/:productId', (req, res) => {
    const userId = 1;
    const productId = req.params.productId;

    if (!userId) {
        return res.status(400).json({ message: 'user_id is required' });
    }

    const query = 'DELETE FROM favourites WHERE user_id = ? AND product_id = ?';
    
    db.query(query, [userId, productId], (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Failed to remove product from favorites', error: err });
        }

        res.status(200).json({ message: 'Product removed from favorites' });
    });
});


app.listen(3004, () => {  
  console.log('Product service listening at http://localhost:3004');
});

