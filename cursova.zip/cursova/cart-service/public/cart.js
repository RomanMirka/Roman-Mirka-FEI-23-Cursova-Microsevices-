document.addEventListener('DOMContentLoaded', () => {
    fetch('http://localhost:3002/api/cart')
        .then(response => response.json())
        .then(cartItems => {
            const cartItemsList = document.querySelector('.cart-items');
            cartItemsList.innerHTML = '';
            cartItems.forEach(item => {
                const li = document.createElement('li');
                li.textContent = `${item.name} - $${item.price}`;
                cartItemsList.appendChild(li);
                updateCartDisplay();
            });
        })
        .catch(error => console.error('Error loading cart items:', error));

    document.querySelector('.clear-cart').addEventListener('click', () => {
        fetch('http://localhost:3002/api/cart', { method: 'DELETE' })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                document.querySelector('.cart-items').innerHTML = '';
                updateCartDisplay(); 
                location.reload();
            })
            .catch(error => console.error('Error clearing cart:', error));
    });
});

function updateCartDisplay() {
    const cartItemsContainer = document.querySelector('.cart-items');
    const emptyCartMessage = document.querySelector('.empty-cart-message');
    
    if (cartItemsContainer.children.length === 0) {
        emptyCartMessage.style.display = 'block';
    } else {
        emptyCartMessage.style.display = 'none';
    }
}


function addToCart(productId) {
    fetch('http://localhost:3002/api/cart', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ product_id: productId })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log('Product added to cart:', data);
        window.location.href = '<script src="../../../../cart-service/public/cart.html';
    })
    .catch(error => console.error('Error adding to cart:', error));
}

document.addEventListener('DOMContentLoaded', () => {
    updateCartDisplay();
});


