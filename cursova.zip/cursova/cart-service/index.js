const express = require('express');
const mysql = require('mysql2');
require('dotenv').config();
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
const port = process.env.PORT || 3002;

const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

db.connect(err => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to the database.');
});

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/api/cart', (req, res) => {
    const query = 'SELECT c.id, c.product_id, p.name, p.price, p.image FROM cart c JOIN product_service.products p ON c.product_id = p.id';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching products:', err);
            res.status(500).json({ error: 'Database error' });
            return;
        }
        res.json(results);
    });
});

app.get('/api/cart/:id', (req, res) => {
    const productId = req.params.id;
    
    const query = 'SELECT * FROM product_service.products WHERE id = ?';
    
    db.query(query, [productId], (err, results) => {
        if (err) {
            console.error('Error fetching product by ID:', err);
            res.status(500).json({ error: 'Database error' });
            return;
        }
        res.json(results[0]);
    });
});

app.post('/api/cart', (req, res) => {
    const { product_id } = req.body;

    if (!product_id) {
        console.error('Product ID is required but not provided');
        return res.status(400).json({ error: 'Product ID is required' });
    }

    console.log('Adding product to cart with product_id:', product_id);

    const query = 'INSERT INTO cart (product_id) VALUES (?)';
    
    db.execute(query, [product_id], (err, results) => {
        if (err) {
            console.error('Error adding product to cart:', err);
            return res.status(500).json({ error: 'Database error', details: err.message });
        }

        console.log('Product added to cart:', results);
        res.status(201).json({ message: 'Product added to cart', cartId: results.insertId });
    });
});

app.delete('/api/cart', (req, res) => {
    const query = 'DELETE FROM cart';

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error deleting cart items:', err);
            return res.status(500).json({ error: 'Database error' });
        }

        console.log('All items deleted from cart');
        res.status(204).send(); 
    });
});



app.listen(port, () => {
    console.log(`Product service listening at http://localhost:${port}/api/cart`);
});
