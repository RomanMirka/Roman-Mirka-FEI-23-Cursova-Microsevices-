document.addEventListener('DOMContentLoaded', async function () {
    const emailElement = document.querySelector('.info-pole h1');
    const token = localStorage.getItem('token'); 

    if (token) {
        try {
            const response = await fetch('http://localhost:3003/api/auth/me', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`, 
                }
            });

            if (response.ok) {
                const userData = await response.json();
                emailElement.textContent = userData.email; 
            } else {
                emailElement.textContent = "Error fetching user info";
            }
        } catch (error) {
            console.error('Error:', error);
            emailElement.textContent = "Error fetching user info";
        }
    } else {
        emailElement.textContent = "User not logged in"; 
    }
});
