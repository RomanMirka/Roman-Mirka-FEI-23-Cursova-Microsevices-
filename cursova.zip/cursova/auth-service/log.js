async function loginUser(event) {
    event.preventDefault();
    console.log("Login form submitted");

    const formData = new FormData(document.getElementById("loginForm"));
    const data = {
        email: formData.get("email"),
        password: formData.get("password")
    };

    const response = await fetch("http://localhost:3003/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });

    if (response.ok) {
        const result = await response.json();
        localStorage.setItem("token", result.token); 
        alert("Login successful");
        window.location.href = "../../main.html"; 
    } else {
        const errorText = await response.text(); 
        alert("Error: " + errorText);
    }
}

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("loginForm").addEventListener("submit", loginUser);
});
