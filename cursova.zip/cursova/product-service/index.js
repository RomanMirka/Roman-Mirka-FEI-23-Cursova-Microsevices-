const express = require('express');
const mysql = require('mysql2');
require('dotenv').config();
const cors = require('cors');

const app = express();
app.use(cors());
const port = 3001;

app.use('/img', express.static('C:/Users/homee/Desktop/Cursovaaa/cursova/img'));

const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

db.connect(err => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to the database.');
});

app.get('/', (req, res) => {
    res.send('Продуктовий сервіс працює!'); 
});

app.get('/api/products', (req, res) => {
    const query = 'SELECT * FROM products';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching products:', err);
            res.status(500).json({ error: 'Database error' });
            return;
        }
        res.json(results);
    });
});

app.get('/api/products/:id', (req, res) => {
    const productId = req.params.id;
    
    const query = 'SELECT * FROM products WHERE id = ?';
    
    db.query(query, [productId], (err, results) => {
        if (err) {
            console.error('Error fetching product by ID:', err);
            res.status(500).json({ error: 'Database error' });
            return;
        }

        if (results.length === 0) {
            res.status(404).json({ error: 'Product not found' });
            return;
        }

        res.json(results[0]);
    });
});


app.listen(port, () => {
    console.log(`Product service listening at http://localhost:${port}`);
});
