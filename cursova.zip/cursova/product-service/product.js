async function fetchProducts() {
    try {
        const [productsResponse, favoritesResponse] = await Promise.all([
            fetch('http://localhost:3001/api/products'),
            fetchWithTimeout('http://127.0.0.1:3004/api/favourites?user_id=1', 5000).catch(error => {
                console.warn('Favourites service request failed or timed out', error);
                return null; 
            })
        ]);

        if (!productsResponse.ok) throw new Error('Failed to fetch products');
        
        const products = await productsResponse.json();
        let favoriteProductIds = [];

        if (favoritesResponse && favoritesResponse.ok) {
            const favData = await favoritesResponse.json();
            favoriteProductIds = favData.map(fav => fav.product_id);
        } else {
            console.warn('Favourites service not available or request timed out');
        }

        renderProducts(products, favoriteProductIds);

        document.querySelector('button').addEventListener('click', () => searchProducts(products));
        document.getElementById('find').addEventListener('keypress', (event) => {
            if (event.key === 'Enter') searchProducts(products);
        });

    } catch (error) {
        console.error('Error fetching products: ', error);
    }
}

function fetchWithTimeout(url, timeout) {
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
            reject(new Error('Request timed out'));
        }, timeout);

        fetch(url).then(
            response => {
                clearTimeout(timer);
                resolve(response);
            },
            err => {
                clearTimeout(timer);
                reject(err);
            }
        );
    });
}

function renderProducts(products, favoriteProductIds = []) {
    const productGrid = document.querySelector('.product-grid');
    productGrid.innerHTML = '';

    products.forEach((product) => {
        const item = document.createElement('div');
        item.className = 'item';

        let productPageLink = '';
        switch (product.name) {
            case 'iPhone 15 Pro Max':
                productPageLink = '/product-service/product_page/iphone15promax.html';
                break;
            case 'Samsung Galaxy':
                productPageLink = '/product-service/product_page/samsunggalaxy.html';
                break;
            case 'iPhone 16 Pro Max':
                productPageLink = '/product-service/product_page/iphone16promax.html';
                break;
            case 'iPhone 14 Pro Max':
                productPageLink = '/product-service/product_page/iphone14promax.html';
                break;
             case 'Ipad Pro 2024':
                productPageLink = '/product-service/product_page/ipadpro2024.html';
                break;
             case 'Google Pixel 9':
                productPageLink = '/product-service/product_page/googlepixel9.html';
                break;
        }

        const likeId = `like-${product.id}`;
        const isLiked = favoriteProductIds.includes(product.id); 

        item.innerHTML = `
            <a href="${productPageLink}">
                <img src="${product.image.replace(/\\/g, '/')}" alt="item" />
            </a>
            <img src="${isLiked ? 'img/heart2.png' : 'img/heart.png'}" 
                 alt="like" id="${likeId}" 
                 class="heart" 
                 onclick="toggleLike(${product.id}, '${likeId}')" />
            <h2 class="price">$${product.price}</h2>
            <div class="glass-item">
                <h2>${product.name}</h2>
            </div>
        `;
        productGrid.appendChild(item);
    });
}

function searchProducts(products) {
    const searchQuery = document.getElementById('find').value.toLowerCase();
    const filteredProducts = products.filter(product =>
        product.name.toLowerCase().includes(searchQuery)
    );
    renderProducts(filteredProducts);
}

fetchProducts();

function toggleLike(productId, likeId) {
    const heartIcon = document.getElementById(likeId);
   if (heartIcon.src.includes('heart2.png')) {
        fetch(`http://127.0.0.1:3004/api/favourites/${productId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            if (response.ok) {
                heartIcon.src = 'img/heart.png';
                console.log('Product removed from favorites');
            } else {
                response.json().then(data => console.error('Failed to remove product from favorites:', data.message));
            }
        })
        .catch(error => console.error('Error:', error));
    } else {
        fetch('http://127.0.0.1:3004/api/favourites', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: 1,  
                product_id: productId
            })
        })
        .then(response => {
            if (response.ok) {
                response.json().then(data => {
                    heartIcon.src = 'img/heart2.png';
                    console.log('Product added to favorites');
                });
            } else {
                response.json().then(data => console.error('Failed to add product to favorites:', data.message));
            }
        })
        .catch(error => console.error('Error:', error));
    }
}
